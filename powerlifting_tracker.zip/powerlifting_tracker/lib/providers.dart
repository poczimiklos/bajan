import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'data/backup_service.dart';
import 'data/database.dart';
import 'data/models.dart';
import 'data/repositories/bodyweight_repository.dart';
import 'data/repositories/exercise_repository.dart';
import 'data/repositories/program_repository.dart';
import 'data/repositories/record_repository.dart';
import 'data/repositories/workout_repository.dart';
import 'data/settings.dart';
import 'data/sync_service.dart';
import 'domain/stats.dart';
import 'features/training/plan.dart';

// ── Infrastructure ──
final sharedPrefsProvider = Provider<SharedPreferences>((ref) => throw UnimplementedError('override in main()'));
final appDatabaseProvider = Provider<AppDatabase>((ref) => AppDatabase());

final exerciseRepoProvider = Provider((ref) => ExerciseRepository(ref.watch(appDatabaseProvider)));
final workoutRepoProvider =
    Provider((ref) => WorkoutRepository(ref.watch(appDatabaseProvider), ref.watch(exerciseRepoProvider)));
final programRepoProvider = Provider((ref) => ProgramRepository(ref.watch(appDatabaseProvider)));
final recordRepoProvider = Provider((ref) => RecordRepository(ref.watch(appDatabaseProvider)));
final bodyweightRepoProvider = Provider((ref) => BodyweightRepository(ref.watch(appDatabaseProvider)));
final backupServiceProvider = Provider((ref) => BackupService(ref.watch(appDatabaseProvider)));

/// Override with a real backend adapter to enable cloud sync.
final remoteGatewayProvider = Provider<RemoteGateway>((ref) => NoRemote());
final syncServiceProvider =
    Provider((ref) => SyncService(ref.watch(appDatabaseProvider), ref.watch(remoteGatewayProvider)));
final syncStatusProvider = FutureProvider.autoDispose<SyncStatus>((ref) => ref.watch(syncServiceProvider).status());

// ── Settings ──
class SettingsNotifier extends Notifier<AppSettings> {
  @override
  AppSettings build() => AppSettings.load(ref.watch(sharedPrefsProvider));

  Future<void> update(AppSettings Function(AppSettings s) change) async {
    state = change(state);
    await state.save(ref.read(sharedPrefsProvider));
  }
}

final settingsProvider = NotifierProvider<SettingsNotifier, AppSettings>(SettingsNotifier.new);

// ── Data ──
final exercisesProvider = FutureProvider<List<Exercise>>((ref) => ref.watch(exerciseRepoProvider).all());
final historyProvider = FutureProvider<List<Workout>>((ref) => ref.watch(workoutRepoProvider).history());
final programsProvider = FutureProvider<List<Program>>((ref) => ref.watch(programRepoProvider).all());
final recordsProvider = FutureProvider<List<PersonalRecord>>((ref) => ref.watch(recordRepoProvider).all());
final bodyweightProvider = FutureProvider<List<BodyweightEntry>>((ref) => ref.watch(bodyweightRepoProvider).all());
final setRecordsProvider = FutureProvider<List<SetRecord>>((ref) => ref.watch(workoutRepoProvider).setRecords());

final statsProvider = Provider<AsyncValue<StatsCalc>>((ref) {
  final formula = ref.watch(settingsProvider.select((s) => s.formula));
  return ref.watch(setRecordsProvider).whenData((r) => StatsCalc(r, formula));
});

final activePlanProvider = FutureProvider<ActivePlan?>((ref) async {
  final blockId = ref.watch(settingsProvider.select((s) => s.activeBlockId));
  if (blockId == null) return null;
  final program = await ref.watch(programRepoProvider).loadByBlock(blockId);
  if (program == null) return null;
  final block = program.blocks.where((b) => b.id == blockId).firstOrNull;
  if (block == null) return null;
  return ActivePlan.compute(program, block, DateTime.now());
});

/// Call after any write that changes derived data.
void refreshAll(WidgetRef ref) {
  ref
    ..invalidate(historyProvider)
    ..invalidate(setRecordsProvider)
    ..invalidate(recordsProvider)
    ..invalidate(programsProvider)
    ..invalidate(activePlanProvider)
    ..invalidate(exercisesProvider)
    ..invalidate(bodyweightProvider)
    ..invalidate(syncStatusProvider);
}
