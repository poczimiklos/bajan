import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import '../../core/theme/app_theme.dart';
import '../../core/widgets/common.dart';
import '../../data/models.dart';
import '../../domain/load_parser.dart';
import '../../providers.dart';
import '../training/exercise_picker.dart';
import '../training/start_workout.dart';

final programDetailProvider = FutureProvider.autoDispose.family<Program?, String>(
  (ref, id) => ref.watch(programRepoProvider).load(id),
);

const _weekdays = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

class ProgramDetailPage extends ConsumerStatefulWidget {
  final String programId;
  const ProgramDetailPage({super.key, required this.programId});
  @override
  ConsumerState<ProgramDetailPage> createState() => _ProgramDetailPageState();
}

class _ProgramDetailPageState extends ConsumerState<ProgramDetailPage> {
  int _block = 0;
  int _week = 0;

  Future<void> _save(Program p) async {
    await ref.read(programRepoProvider).save(p);
    ref.invalidate(programDetailProvider(widget.programId));
    refreshAll(ref);
  }

  @override
  Widget build(BuildContext context) {
    final async = ref.watch(programDetailProvider(widget.programId));
    final settings = ref.watch(settingsProvider);
    final exercises = ref.watch(exercisesProvider).valueOrNull ?? const <Exercise>[];
    final exName = {for (final e in exercises) e.id: e.name};

    return AsyncView<Program?>(
      value: async,
      onRetry: () => ref.invalidate(programDetailProvider(widget.programId)),
      data: (program) {
        if (program == null) {
          return Scaffold(appBar: AppBar(), body: const EmptyState(icon: Icons.search_off, title: 'Program not found'));
        }
        if (program.blocks.isEmpty) program.blocks.add(ProgramBlock(name: 'Block 1', weekCount: 4));
        _block = _block.clamp(0, program.blocks.length - 1);
        final block = program.blocks[_block];
        _week = _week.clamp(0, block.weekCount - 1);
        final isActive = settings.activeBlockId == block.id;
        final days = [...block.days]..sort((a, b) => a.weekday.compareTo(b.weekday));

        return Scaffold(
          appBar: AppBar(
            title: Text(program.name, overflow: TextOverflow.ellipsis),
            actions: [
              PopupMenuButton<String>(
                onSelected: (v) => _programAction(v, program),
                itemBuilder: (c) => const [
                  PopupMenuItem(value: 'rename', child: Text('Rename program')),
                  PopupMenuItem(value: 'duplicate', child: Text('Duplicate program')),
                  PopupMenuItem(value: 'delete', child: Text('Delete program')),
                ],
              ),
            ],
          ),
          body: ListView(padding: const EdgeInsets.fromLTRB(16, 0, 16, 32), children: [
            if (program.description.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: Text(program.description, style: TextStyle(color: context.muted)),
              ),
            // ── blocks ──
            SizedBox(
              height: 44,
              child: ListView(scrollDirection: Axis.horizontal, children: [
                for (var i = 0; i < program.blocks.length; i++)
                  Padding(
                    padding: const EdgeInsets.only(right: 6),
                    child: ChoiceChip(
                      label: Text(program.blocks[i].name),
                      selected: _block == i,
                      onSelected: (_) => setState(() {
                        _block = i;
                        _week = 0;
                      }),
                    ),
                  ),
                ActionChip(
                  avatar: const Icon(Icons.add, size: 18),
                  label: const Text('Block'),
                  onPressed: () async {
                    program.blocks.add(ProgramBlock(name: 'Block ${program.blocks.length + 1}', weekCount: 4));
                    setState(() => _block = program.blocks.length - 1);
                    await _save(program);
                  },
                ),
              ]),
            ),
            AppCard(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Expanded(
                    child: Text(
                      '${block.name} · ${block.weekCount} weeks'
                      '${block.startDate == null ? '' : ' · from ${DateFormat('d MMM yyyy').format(block.startDate!)}'}',
                      style: const TextStyle(fontWeight: FontWeight.w800),
                    ),
                  ),
                  if (isActive) Chip(label: const Text('Active'), visualDensity: VisualDensity.compact, backgroundColor: context.accent.withValues(alpha: 0.25)),
                ]),
                const SizedBox(height: 10),
                Wrap(spacing: 8, runSpacing: 4, children: [
                  OutlinedButton(
                    style: OutlinedButton.styleFrom(minimumSize: const Size(48, 40)),
                    onPressed: () => _activate(program, block),
                    child: Text(isActive ? 'Change start date' : 'Activate block'),
                  ),
                  OutlinedButton(
                    style: OutlinedButton.styleFrom(minimumSize: const Size(48, 40)),
                    onPressed: () => _nextBlock(program, block),
                    child: const Text('Create next block'),
                  ),
                  OutlinedButton(
                    style: OutlinedButton.styleFrom(minimumSize: const Size(48, 40)),
                    onPressed: () => _blockSettings(program, block),
                    child: const Text('Block settings'),
                  ),
                ]),
              ]),
            ),
            // ── weeks ──
            const SectionTitle('Week'),
            SizedBox(
              height: 44,
              child: ListView(scrollDirection: Axis.horizontal, children: [
                for (var w = 0; w < block.weekCount; w++)
                  Padding(
                    padding: const EdgeInsets.only(right: 6),
                    child: ChoiceChip(label: Text('W${w + 1}'), selected: _week == w, onSelected: (_) => setState(() => _week = w)),
                  ),
              ]),
            ),
            // ── days ──
            for (final d in days) _dayCard(program, block, d, exName),
            const SizedBox(height: 12),
            OutlinedButton.icon(
              icon: const Icon(Icons.add),
              label: const Text('Add training day'),
              onPressed: () => _addDay(program, block),
            ),
          ]),
        );
      },
    );
  }

  Widget _dayCard(Program program, ProgramBlock block, ProgramDay d, Map<String, String> exName) {
    final has = d.hasWork(_week);
    return Padding(
      padding: const EdgeInsets.only(top: 12),
      child: AppCard(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Expanded(
              child: Text('${_weekdays[d.weekday - 1]} · ${d.name}', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
            ),
            if (d.tag.isNotEmpty) Chip(label: Text(d.tag), visualDensity: VisualDensity.compact),
            PopupMenuButton<String>(
              onSelected: (v) => _dayAction(v, program, block, d),
              itemBuilder: (c) => const [
                PopupMenuItem(value: 'edit', child: Text('Edit day')),
                PopupMenuItem(value: 'delete', child: Text('Delete day')),
              ],
            ),
          ]),
          if (d.tag.isNotEmpty && describeTag(d.tag).isNotEmpty)
            Text(describeTag(d.tag), style: TextStyle(color: context.muted, fontSize: 12)),
          const SizedBox(height: 8),
          for (final pe in d.exercises)
            InkWell(
                borderRadius: BorderRadius.circular(10),
                onTap: () => _editSets(program, block, d, pe, exName[pe.exerciseId] ?? pe.exerciseId),
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 6),
                  child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(exName[pe.exerciseId] ?? pe.exerciseId, style: const TextStyle(fontWeight: FontWeight.w700)),
                        if (pe.forWeek(_week).isEmpty)
                          Text('Nothing prescribed this week', style: TextStyle(color: context.muted, fontSize: 12))
                        else
                          for (final s in pe.forWeek(_week))
                            Text(
                              '${s.describe()}${s.note.isEmpty ? '' : ' · ${s.note}'}',
                              style: TextStyle(color: context.muted, fontSize: 13),
                            ),
                      ]),
                    ),
                    Icon(Icons.edit_outlined, size: 16, color: context.muted),
                  ]),
                ),
              ),
          const SizedBox(height: 8),
          Row(children: [
            TextButton.icon(
              icon: const Icon(Icons.add, size: 18),
              label: const Text('Exercise'),
              onPressed: () async {
                final ex = await pickExercise(context);
                if (ex == null) return;
                d.exercises.add(ProgramExercise(exerciseId: ex.id, sets: [
                  PrescribedSet(weekIndex: _week, sets: 3, repsMin: 5, repsMax: 5),
                ]));
                await _save(program);
              },
            ),
            const Spacer(),
            if (has)
              FilledButton(
                style: FilledButton.styleFrom(minimumSize: const Size(100, 40)),
                onPressed: () => StartWorkout.fromDay(context, ref, program: program, block: block, day: d, week: _week),
                child: Text('Start W${_week + 1}'),
              ),
          ]),
        ]),
      ),
    );
  }

  // ── actions ──
  Future<void> _programAction(String v, Program p) async {
    switch (v) {
      case 'rename':
        final name = await _askText('Rename program', p.name);
        if (name != null && name.isNotEmpty) {
          p.name = name;
          await _save(p);
        }
      case 'duplicate':
        final copy = ref.read(programRepoProvider).duplicate(p);
        await ref.read(programRepoProvider).save(copy);
        refreshAll(ref);
        if (mounted) context.pushReplacement('/program/${copy.id}');
      case 'delete':
        final ok = await _confirm('Delete "${p.name}"?', 'Logged workouts are kept.');
        if (ok != true) return;
        final active = ref.read(settingsProvider).activeBlockId;
        if (p.blocks.any((b) => b.id == active)) {
          await ref.read(settingsProvider.notifier).update((s) => s.copyWith(activeBlockId: null));
        }
        await ref.read(programRepoProvider).delete(p.id);
        refreshAll(ref);
        if (mounted) context.pop();
    }
  }

  Future<void> _activate(Program p, ProgramBlock b) async {
    final picked = await showDatePicker(
      context: context,
      initialDate: b.startDate ?? DateTime.now(),
      firstDate: DateTime(2020),
      lastDate: DateTime(2100),
      helpText: 'Block start date (week 1)',
    );
    if (picked == null) return;
    b.startDate = picked;
    await ref.read(settingsProvider.notifier).update((s) => s.copyWith(activeBlockId: b.id));
    await _save(p);
    if (mounted) snack(context, '${b.name} is now your active block.');
  }

  Future<void> _nextBlock(Program p, ProgramBlock b) async {
    final c = TextEditingController(text: '5');
    final inc = await showDialog<double>(
      context: context,
      builder: (d) => AlertDialog(
        title: const Text('Create next block'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text('Copies this block and adds a fixed amount to every absolute weight.'),
          const SizedBox(height: 12),
          TextField(
            controller: c,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: const InputDecoration(labelText: 'Add (kg)'),
          ),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(d), child: const Text('Cancel')),
          TextButton(onPressed: () => Navigator.pop(d, parseNum(c.text) ?? 0), child: const Text('Create')),
        ],
      ),
    );
    if (inc == null) return;
    final start = b.startDate?.add(Duration(days: b.weekCount * 7));
    final nb = ref.read(programRepoProvider).duplicateBlock(b, start: start);
    nb.name = 'Block ${p.blocks.length + 1}';
    for (final d in nb.days) {
      for (final e in d.exercises) {
        for (final s in e.sets) {
          if (s.loadType == LoadType.abs && s.weight != null) {
            s.weight = s.weight! + inc;
            if (s.weightMax != null) s.weightMax = s.weightMax! + inc;
          }
        }
      }
    }
    p.blocks.add(nb);
    setState(() {
      _block = p.blocks.length - 1;
      _week = 0;
    });
    await _save(p);
  }

  Future<void> _blockSettings(Program p, ProgramBlock b) async {
    final name = TextEditingController(text: b.name);
    final weeks = TextEditingController(text: '${b.weekCount}');
    final result = await showDialog<String>(
      context: context,
      builder: (d) => AlertDialog(
        title: const Text('Block settings'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: name, decoration: const InputDecoration(labelText: 'Name')),
          const SizedBox(height: 12),
          TextField(controller: weeks, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Weeks')),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(d, 'delete'), child: const Text('Delete block')),
          TextButton(onPressed: () => Navigator.pop(d), child: const Text('Cancel')),
          TextButton(onPressed: () => Navigator.pop(d, 'save'), child: const Text('Save')),
        ],
      ),
    );
    if (result == 'save') {
      b.name = name.text.trim().isEmpty ? b.name : name.text.trim();
      b.weekCount = (int.tryParse(weeks.text) ?? b.weekCount).clamp(1, 30);
      await _save(p);
    } else if (result == 'delete') {
      if (p.blocks.length == 1) {
        if (mounted) snack(context, 'A program needs at least one block.');
        return;
      }
      p.blocks.remove(b);
      setState(() => _block = 0);
      await _save(p);
    }
  }

  Future<void> _addDay(Program p, ProgramBlock b) async {
    final name = TextEditingController(text: 'Day ${b.days.length + 1}');
    final tag = TextEditingController();
    var weekday = DateTime.monday;
    final ok = await showDialog<bool>(
      context: context,
      builder: (d) => StatefulBuilder(
        builder: (d, setS) => AlertDialog(
          title: const Text('New training day'),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(controller: name, decoration: const InputDecoration(labelText: 'Name')),
            const SizedBox(height: 12),
            DropdownButtonFormField<int>(
              value: weekday,
              decoration: const InputDecoration(labelText: 'Weekday'),
              items: [for (var i = 1; i <= 7; i++) DropdownMenuItem(value: i, child: Text(_weekdays[i - 1]))],
              onChanged: (v) => setS(() => weekday = v ?? 1),
            ),
            const SizedBox(height: 12),
            TextField(controller: tag, decoration: const InputDecoration(labelText: 'Tag (optional, e.g. SQ1 BP2)')),
          ]),
          actions: [
            TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Cancel')),
            TextButton(onPressed: () => Navigator.pop(d, true), child: const Text('Add')),
          ],
        ),
      ),
    );
    if (ok != true) return;
    b.days.add(ProgramDay(name: name.text.trim().isEmpty ? 'Day' : name.text.trim(), weekday: weekday, tag: tag.text.trim().toUpperCase()));
    await _save(p);
  }

  Future<void> _dayAction(String v, Program p, ProgramBlock b, ProgramDay d) async {
    if (v == 'delete') {
      if (await _confirm('Delete ${d.name}?', 'Its prescriptions are removed from this block.') == true) {
        b.days.remove(d);
        await _save(p);
      }
      return;
    }
    final name = TextEditingController(text: d.name);
    final tag = TextEditingController(text: d.tag);
    var weekday = d.weekday;
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => StatefulBuilder(
        builder: (c, setS) => AlertDialog(
          title: const Text('Edit day'),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(controller: name, decoration: const InputDecoration(labelText: 'Name')),
            const SizedBox(height: 12),
            DropdownButtonFormField<int>(
              value: weekday,
              decoration: const InputDecoration(labelText: 'Weekday'),
              items: [for (var i = 1; i <= 7; i++) DropdownMenuItem(value: i, child: Text(_weekdays[i - 1]))],
              onChanged: (x) => setS(() => weekday = x ?? 1),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: tag,
              decoration: const InputDecoration(labelText: 'Tag', helperText: 'SQ1 = primary squat, SQ2 = secondary squat, …'),
            ),
          ]),
          actions: [
            TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Cancel')),
            TextButton(onPressed: () => Navigator.pop(c, true), child: const Text('Save')),
          ],
        ),
      ),
    );
    if (ok != true) return;
    d.name = name.text.trim().isEmpty ? d.name : name.text.trim();
    d.weekday = weekday;
    d.tag = tag.text.trim().toUpperCase();
    await _save(p);
  }

  Future<void> _editSets(Program p, ProgramBlock b, ProgramDay d, ProgramExercise pe, String title) async {
    final result = await showModalBottomSheet<_SheetResult>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (c) => _SetsEditor(title: title, week: _week, weekCount: b.weekCount, initial: pe.forWeek(_week)),
    );
    if (result == null) return;
    if (result.removeExercise) {
      d.exercises.remove(pe);
      await _save(p);
      return;
    }
    pe.sets.removeWhere((s) => s.weekIndex == _week);
    for (var i = 0; i < result.sets.length; i++) {
      result.sets[i].position = i;
      pe.sets.add(result.sets[i]);
    }
    if (result.propagate) {
      pe.sets.removeWhere((s) => s.weekIndex > _week);
      for (var w = _week + 1; w < b.weekCount; w++) {
        for (final s in result.sets) {
          final n = s.copyForWeek(w);
          if (n.loadType == LoadType.abs && n.weight != null) {
            n.weight = n.weight! + result.step * (w - _week);
            if (n.weightMax != null) n.weightMax = n.weightMax! + result.step * (w - _week);
          }
          pe.sets.add(n);
        }
      }
    }
    await _save(p);
  }

  Future<String?> _askText(String title, String initial) {
    final c = TextEditingController(text: initial);
    return showDialog<String>(
      context: context,
      builder: (d) => AlertDialog(
        title: Text(title),
        content: TextField(controller: c, autofocus: true),
        actions: [
          TextButton(onPressed: () => Navigator.pop(d), child: const Text('Cancel')),
          TextButton(onPressed: () => Navigator.pop(d, c.text.trim()), child: const Text('Save')),
        ],
      ),
    );
  }

  Future<bool?> _confirm(String title, String msg) => showDialog<bool>(
        context: context,
        builder: (d) => AlertDialog(
          title: Text(title),
          content: Text(msg),
          actions: [
            TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Cancel')),
            TextButton(onPressed: () => Navigator.pop(d, true), child: const Text('Delete')),
          ],
        ),
      );
}

// ─────────────────────────── prescription editor ───────────────────────────

class _SheetResult {
  final List<PrescribedSet> sets;
  final bool propagate;
  final double step;
  final bool removeExercise;
  _SheetResult(this.sets, {this.propagate = false, this.step = 0, this.removeExercise = false});
}

/// Applies coach-style load text ("205", "[145-155] R5-6", "75%", "R8-9", "max", "last +2.5").
void _applyLoadText(PrescribedSet ps, String raw) {
  final t = raw.trim().toLowerCase();
  ps
    ..weight = null
    ..weightMax = null
    ..rpeMin = null
    ..rpeMax = null
    ..constant = false
    ..repeatUntil = false;
  if (t.isEmpty) {
    ps.loadType = LoadType.free;
    return;
  }
  if (t.startsWith('last')) {
    ps.loadType = LoadType.linear;
    ps.weight = parseNum(t.replaceAll(RegExp(r'[^0-9.,]'), '')) ?? 0;
    return;
  }
  final p = parsePrescription(raw);
  ps
    ..rpeMin = p.rpeMin
    ..rpeMax = p.rpeMax
    ..constant = p.isConstant
    ..repeatUntil = p.isRepeat;
  if (p.isMax) {
    ps.loadType = LoadType.max;
  } else if (p.isPercent) {
    ps.loadType = LoadType.pct;
    ps.weight = p.weight;
  } else if (p.weight != null) {
    ps.loadType = LoadType.abs;
    ps.weight = p.weight;
    ps.weightMax = p.weightMax;
  } else if (p.rpeMin != null) {
    ps.loadType = LoadType.rpe;
  } else {
    ps.loadType = LoadType.free;
  }
}

class _RowCtl {
  final PrescribedSet set;
  final TextEditingController sets;
  final TextEditingController reps;
  final TextEditingController load;
  final TextEditingController note;
  _RowCtl(this.set)
      : sets = TextEditingController(text: '${set.sets}'),
        reps = TextEditingController(text: set.repsText),
        load = TextEditingController(text: set.loadText == 'last +?' ? '' : set.loadText),
        note = TextEditingController(text: set.note);
}

class _SetsEditor extends StatefulWidget {
  final String title;
  final int week;
  final int weekCount;
  final List<PrescribedSet> initial;
  const _SetsEditor({required this.title, required this.week, required this.weekCount, required this.initial});
  @override
  State<_SetsEditor> createState() => _SetsEditorState();
}

class _SetsEditorState extends State<_SetsEditor> {
  late final List<_RowCtl> _rows = [for (final s in widget.initial) _RowCtl(s.copyForWeek(widget.week))];
  final _step = TextEditingController(text: '2.5');

  List<PrescribedSet> _collect() {
    final out = <PrescribedSet>[];
    for (final r in _rows) {
      final s = r.set;
      s.sets = (int.tryParse(r.sets.text) ?? 1).clamp(1, 30);
      final (a, b) = parseReps(r.reps.text);
      s.repsMin = a;
      s.repsMax = b;
      s.note = r.note.text.trim();
      _applyLoadText(s, r.load.text);
      out.add(s);
    }
    return out;
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.fromLTRB(16, 0, 16, 16 + MediaQuery.of(context).viewInsets.bottom),
      child: SingleChildScrollView(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(widget.title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
          Text('Week ${widget.week + 1}', style: TextStyle(color: context.muted)),
          const SizedBox(height: 4),
          Text(
            'Load examples: 205 · [145-155] R5-6 · 75% · R8-9 · max · last +2.5',
            style: TextStyle(color: context.muted, fontSize: 12),
          ),
          const SizedBox(height: 12),
          for (var i = 0; i < _rows.length; i++)
            Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: Column(children: [
                Row(children: [
                  SizedBox(
                    width: 56,
                    child: TextField(
                      controller: _rows[i].sets,
                      keyboardType: TextInputType.number,
                      textAlign: TextAlign.center,
                      decoration: const InputDecoration(labelText: 'Sets'),
                    ),
                  ),
                  const SizedBox(width: 8),
                  SizedBox(
                    width: 72,
                    child: TextField(
                      controller: _rows[i].reps,
                      textAlign: TextAlign.center,
                      decoration: const InputDecoration(labelText: 'Reps'),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: TextField(controller: _rows[i].load, decoration: const InputDecoration(labelText: 'Load')),
                  ),
                  IconButton(
                    onPressed: () => setState(() => _rows.removeAt(i)),
                    icon: const Icon(Icons.delete_outline),
                    tooltip: 'Remove row',
                  ),
                ]),
                const SizedBox(height: 6),
                TextField(controller: _rows[i].note, decoration: const InputDecoration(labelText: 'Note (optional)', isDense: true)),
              ]),
            ),
          OutlinedButton.icon(
            icon: const Icon(Icons.add),
            label: const Text('Add row'),
            onPressed: () => setState(() => _rows.add(_RowCtl(PrescribedSet(weekIndex: widget.week, sets: 3, repsMin: 5, repsMax: 5)))),
          ),
          const SizedBox(height: 12),
          FilledButton(onPressed: () => Navigator.pop(context, _SheetResult(_collect())), child: const Text('Save this week')),
          if (widget.week < widget.weekCount - 1) ...[
            const SizedBox(height: 12),
            Row(children: [
              SizedBox(
                width: 110,
                child: TextField(
                  controller: _step,
                  keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  decoration: const InputDecoration(labelText: '+kg / week'),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: OutlinedButton(
                  onPressed: () => Navigator.pop(
                    context,
                    _SheetResult(_collect(), propagate: true, step: parseNum(_step.text) ?? 0),
                  ),
                  child: const Text('Save & fill later weeks'),
                ),
              ),
            ]),
          ],
          const SizedBox(height: 8),
          TextButton(
            onPressed: () => Navigator.pop(context, _SheetResult(const [], removeExercise: true)),
            child: const Text('Remove exercise from this day', style: TextStyle(color: AppColors.danger)),
          ),
        ]),
      ),
    );
  }
}
