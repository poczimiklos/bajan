import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../core/theme/app_theme.dart';
import '../training/rest_timer.dart';
import '../training/workout_editor.dart';

const _tabs = [
  ('/', Icons.dashboard_outlined, Icons.dashboard, 'Dashboard'),
  ('/training', Icons.fitness_center_outlined, Icons.fitness_center, 'Training'),
  ('/programs', Icons.event_note_outlined, Icons.event_note, 'Programs'),
  ('/stats', Icons.show_chart_outlined, Icons.show_chart, 'Statistics'),
  ('/profile', Icons.person_outline, Icons.person, 'Profile'),
];

class AppShell extends ConsumerWidget {
  final String location;
  final Widget child;
  const AppShell({super.key, required this.location, required this.child});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final index = _tabs.indexWhere((t) => t.$1 == location).clamp(0, _tabs.length - 1);
    final active = ref.watch(workoutEditorProvider);
    return Scaffold(
      body: SafeArea(bottom: false, child: child),
      bottomNavigationBar: Column(mainAxisSize: MainAxisSize.min, children: [
        const RestTimerBar(),
        if (active != null && active.status == 'active')
          Material(
            color: context.accent,
            child: InkWell(
              onTap: () => context.push('/workout'),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                child: Row(children: [
                  Icon(Icons.play_arrow_rounded, color: context.cs.onPrimary),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text('Workout in progress · ${active.name}',
                        style: TextStyle(color: context.cs.onPrimary, fontWeight: FontWeight.w700)),
                  ),
                  Icon(Icons.chevron_right, color: context.cs.onPrimary),
                ]),
              ),
            ),
          ),
        NavigationBar(
          selectedIndex: index,
          onDestinationSelected: (i) => context.go(_tabs[i].$1),
          destinations: [
            for (final t in _tabs)
              NavigationDestination(icon: Icon(t.$2), selectedIcon: Icon(t.$3), label: t.$4),
          ],
        ),
      ]),
    );
  }
}
