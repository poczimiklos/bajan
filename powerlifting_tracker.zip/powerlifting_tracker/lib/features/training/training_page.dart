import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import '../../core/theme/app_theme.dart';
import '../../core/widgets/common.dart';
import '../../data/models.dart';
import '../../providers.dart';
import 'start_workout.dart';
import 'workout_editor.dart';

class TrainingPage extends ConsumerWidget {
  const TrainingPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final history = ref.watch(historyProvider);
    final plan = ref.watch(activePlanProvider).valueOrNull;
    final settings = ref.watch(settingsProvider);
    final active = ref.watch(workoutEditorProvider);

    return AsyncView<List<Workout>>(
      value: history,
      onRetry: () => ref.invalidate(historyProvider),
      data: (list) => ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Training', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800)),
          const SizedBox(height: 16),
          if (active != null && active.status == 'active')
            FilledButton.icon(
              icon: const Icon(Icons.play_arrow_rounded),
              onPressed: () => context.push('/workout'),
              label: Text('Resume · ${active.name}'),
            )
          else
            FilledButton.icon(
              icon: const Icon(Icons.add),
              onPressed: () => StartWorkout.empty(context, ref),
              label: const Text('Start empty workout'),
            ),
          if (plan != null && plan.today != null) ...[
            const SizedBox(height: 10),
            OutlinedButton.icon(
              icon: const Icon(Icons.event_available),
              onPressed: () => StartWorkout.fromPlan(context, ref, plan),
              label: Text('Start today: ${plan.today!.name} (${plan.weekLabel})'),
            ),
          ],
          const SectionTitle('History'),
          if (list.isEmpty)
            const SizedBox(
              height: 260,
              child: EmptyState(
                icon: Icons.fitness_center,
                title: 'No workouts yet',
                message: 'Your finished workouts will appear here. Start one above.',
              ),
            )
          else
            for (final w in list) _HistoryTile(workout: w, unit: settings.unitLabel, toDisplay: settings.toDisplay),
        ],
      ),
    );
  }
}

class _HistoryTile extends ConsumerWidget {
  final Workout workout;
  final String unit;
  final double Function(double) toDisplay;
  const _HistoryTile({required this.workout, required this.unit, required this.toDisplay});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final w = workout;
    final sets = w.completedSets.length;
    final names = w.exercises.map((e) => e.exercise.name).take(3).join(', ');
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: AppCard(
        onTap: () async {
          await ref.read(workoutEditorProvider.notifier).loadForEdit(w.id);
          if (context.mounted) context.push('/workout');
        },
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Expanded(child: Text(w.name, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800))),
            if (w.tag.isNotEmpty) Chip(label: Text(w.tag), visualDensity: VisualDensity.compact),
            const SizedBox(width: 6),
            Text(DateFormat('EEE d MMM').format(w.date), style: TextStyle(color: context.muted, fontSize: 12)),
          ]),
          const SizedBox(height: 6),
          Text(names + (w.exercises.length > 3 ? ' +${w.exercises.length - 3}' : ''),
              style: TextStyle(color: context.muted), maxLines: 1, overflow: TextOverflow.ellipsis),
          const SizedBox(height: 8),
          Row(children: [
            _pill(context, Icons.layers, '$sets sets'),
            const SizedBox(width: 12),
            _pill(context, Icons.scale, '${fmtNum(toDisplay(w.volume), decimals: 0)} $unit'),
            if (w.endedAt != null) ...[
              const SizedBox(width: 12),
              _pill(context, Icons.timer_outlined, '${w.endedAt!.difference(w.startedAt).inMinutes} min'),
            ],
          ]),
        ]),
      ),
    );
  }

  Widget _pill(BuildContext c, IconData i, String t) => Row(children: [
        Icon(i, size: 14, color: c.muted),
        const SizedBox(width: 4),
        Text(t, style: TextStyle(fontSize: 12, color: c.muted)),
      ]);
}
