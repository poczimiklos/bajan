import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import 'package:wakelock_plus/wakelock_plus.dart';
import '../../core/theme/app_theme.dart';
import '../../core/widgets/common.dart';
import '../../data/models.dart';
import '../../data/settings.dart';
import '../../domain/e1rm.dart';
import '../../domain/plates.dart';
import '../../providers.dart';
import 'exercise_picker.dart';
import 'pr_dialog.dart';
import 'rest_timer.dart';
import 'workout_editor.dart';

/// Previous performance of an exercise: key = (exerciseId, currentWorkoutId).
final _lastPerfProvider = FutureProvider.family<List<SetEntry>, (String, String)>(
  (ref, key) => ref.watch(workoutRepoProvider).lastPerformance(key.$1, excludeWorkoutId: key.$2),
);

class WorkoutPage extends ConsumerStatefulWidget {
  const WorkoutPage({super.key});
  @override
  ConsumerState<WorkoutPage> createState() => _WorkoutPageState();
}

class _WorkoutPageState extends ConsumerState<WorkoutPage> {
  @override
  void initState() {
    super.initState();
    WakelockPlus.enable(); // keep the screen on in the gym
  }

  @override
  void dispose() {
    WakelockPlus.disable();
    super.dispose();
  }

  Future<void> _finish() async {
    final w = ref.read(workoutEditorProvider);
    if (w == null) return;
    if (w.completedSets.isEmpty) {
      snack(context, 'Complete at least one set first.');
      return;
    }
    final open = w.exercises.expand((e) => e.sets).where((s) => !s.completed && (s.weight != null || s.reps != null)).length;
    if (open > 0) {
      final ok = await showDialog<bool>(
        context: context,
        builder: (c) => AlertDialog(
          title: const Text('Finish workout?'),
          content: Text('$open set${open == 1 ? '' : 's'} not marked as done. They will be kept but not counted in statistics.'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Keep logging')),
            TextButton(onPressed: () => Navigator.pop(c, true), child: const Text('Finish')),
          ],
        ),
      );
      if (ok != true) return;
    }
    ref.read(restTimerProvider.notifier).stop();
    final prs = await ref.read(workoutEditorProvider.notifier).finish();
    refreshAll(ref);
    if (!mounted) return;
    if (prs.isNotEmpty) await showPrDialog(context, prs, ref.read(settingsProvider));
    if (mounted) context.go('/training');
  }

  Future<void> _discard(bool isEdit) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: Text(isEdit ? 'Delete workout?' : 'Discard workout?'),
        content: const Text('This cannot be undone.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Cancel')),
          TextButton(onPressed: () => Navigator.pop(c, true), child: Text(isEdit ? 'Delete' : 'Discard')),
        ],
      ),
    );
    if (ok != true) return;
    ref.read(restTimerProvider.notifier).stop();
    await ref.read(workoutEditorProvider.notifier).discard();
    refreshAll(ref);
    if (mounted) context.go('/training');
  }

  @override
  Widget build(BuildContext context) {
    final w = ref.watch(workoutEditorProvider);
    final editor = ref.read(workoutEditorProvider.notifier);
    if (w == null) {
      return Scaffold(
        appBar: AppBar(),
        body: const EmptyState(icon: Icons.fitness_center, title: 'No workout open'),
      );
    }
    final isEdit = w.status == 'done';
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            if (isEdit) editor.closeEditor();
            context.canPop() ? context.pop() : context.go('/training');
          },
        ),
        title: InkWell(
          onTap: () async {
            final c = TextEditingController(text: w.name);
            final name = await showDialog<String>(
              context: context,
              builder: (d) => AlertDialog(
                title: const Text('Workout name'),
                content: TextField(controller: c, autofocus: true),
                actions: [
                  TextButton(onPressed: () => Navigator.pop(d), child: const Text('Cancel')),
                  TextButton(onPressed: () => Navigator.pop(d, c.text.trim()), child: const Text('Save')),
                ],
              ),
            );
            if (name != null && name.isNotEmpty) editor.rename(name);
          },
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(w.name, overflow: TextOverflow.ellipsis),
            isEdit
                ? Text('Editing · ${DateFormat.yMMMd().format(w.date)}', style: TextStyle(fontSize: 12, color: context.muted))
                : _Elapsed(start: w.startedAt),
          ]),
        ),
        actions: [
          PopupMenuButton<String>(
            onSelected: (v) {
              if (v == 'discard') _discard(isEdit);
            },
            itemBuilder: (c) => [PopupMenuItem(value: 'discard', child: Text(isEdit ? 'Delete workout' : 'Discard workout'))],
          ),
          Padding(
            padding: const EdgeInsets.only(right: 8),
            child: FilledButton(
              style: FilledButton.styleFrom(minimumSize: const Size(72, 40)),
              onPressed: _finish,
              child: Text(isEdit ? 'Save' : 'Finish'),
            ),
          ),
        ],
      ),
      body: Column(children: [
        Expanded(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(12, 4, 12, 32),
            children: [
              _Header(workout: w),
              for (final we in w.exercises) _ExerciseCard(key: ValueKey(we.id), workout: w, we: we),
              const SizedBox(height: 8),
              OutlinedButton.icon(
                icon: const Icon(Icons.add),
                label: const Text('Add exercise'),
                onPressed: () async {
                  final ex = await pickExercise(context);
                  if (ex != null) await editor.addExercise(ex);
                },
              ),
              const SizedBox(height: 12),
              TextFormField(
                initialValue: w.notes,
                minLines: 1,
                maxLines: 4,
                decoration: const InputDecoration(hintText: 'Workout notes'),
                onChanged: editor.setNotes,
              ),
            ],
          ),
        ),
        const RestTimerBar(),
      ]),
    );
  }
}

class _Elapsed extends StatefulWidget {
  final DateTime start;
  const _Elapsed({required this.start});
  @override
  State<_Elapsed> createState() => _ElapsedState();
}

class _ElapsedState extends State<_Elapsed> {
  Timer? _t;
  @override
  void initState() {
    super.initState();
    _t = Timer.periodic(const Duration(seconds: 1), (_) => mounted ? setState(() {}) : null);
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final d = DateTime.now().difference(widget.start);
    final h = d.inHours;
    final m = (d.inMinutes % 60).toString().padLeft(2, '0');
    final s = (d.inSeconds % 60).toString().padLeft(2, '0');
    return Text(h > 0 ? '$h:$m:$s' : '$m:$s', style: TextStyle(fontSize: 12, color: context.muted));
  }
}

// ─────────────────────────── Header / check-in ───────────────────────────

class _Header extends ConsumerWidget {
  final Workout workout;
  const _Header({required this.workout});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final w = workout;
    final editor = ref.read(workoutEditorProvider.notifier);
    final checked = w.stress != null || w.fatigueSq != null || w.fatigueBp != null || w.fatigueDl != null;
    Widget scale(String label, int? value, void Function(int) onPick) => Padding(
          padding: const EdgeInsets.symmetric(vertical: 4),
          child: Row(children: [
            SizedBox(width: 70, child: Text(label, style: TextStyle(color: context.muted))),
            for (var i = 1; i <= 5; i++)
              Padding(
                padding: const EdgeInsets.only(right: 6),
                child: ChoiceChip(
                  label: Text('$i'),
                  selected: value == i,
                  onSelected: (_) => onPick(i),
                  visualDensity: VisualDensity.compact,
                ),
              ),
          ]),
        );
    return Column(children: [
      if (w.tag.isNotEmpty)
        Padding(
          padding: const EdgeInsets.only(bottom: 8),
          child: Row(children: [
            Chip(label: Text(w.tag, style: const TextStyle(fontWeight: FontWeight.w700))),
            const SizedBox(width: 8),
            Expanded(child: Text(describeTag(w.tag), style: TextStyle(color: context.muted, fontSize: 12))),
          ]),
        ),
      AppCard(
        padding: EdgeInsets.zero,
        child: Theme(
          data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
          child: ExpansionTile(
            title: const Text('Check-in', style: TextStyle(fontWeight: FontWeight.w700)),
            subtitle: Text(
              checked
                  ? 'Stress ${w.stress ?? '–'} · SQ ${w.fatigueSq ?? '–'} · BP ${w.fatigueBp ?? '–'} · DL ${w.fatigueDl ?? '–'}'
                  : 'Stress and fatigue (1 = low, 5 = high)',
              style: TextStyle(color: context.muted, fontSize: 12),
            ),
            childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
            children: [
              scale('Stress', w.stress, (v) => editor.setCheckIn(stress: v)),
              scale('Fatigue SQ', w.fatigueSq, (v) => editor.setCheckIn(sq: v)),
              scale('Fatigue BP', w.fatigueBp, (v) => editor.setCheckIn(bp: v)),
              scale('Fatigue DL', w.fatigueDl, (v) => editor.setCheckIn(dl: v)),
            ],
          ),
        ),
      ),
      const SizedBox(height: 12),
    ]);
  }
}

// ─────────────────────────── Exercise card ───────────────────────────

class _ExerciseCard extends ConsumerStatefulWidget {
  final Workout workout;
  final WorkoutExercise we;
  const _ExerciseCard({super.key, required this.workout, required this.we});
  @override
  ConsumerState<_ExerciseCard> createState() => _ExerciseCardState();
}

class _ExerciseCardState extends ConsumerState<_ExerciseCard> {
  bool _showNotes = false;

  @override
  Widget build(BuildContext context) {
    final we = widget.we;
    final settings = ref.watch(settingsProvider);
    final editor = ref.read(workoutEditorProvider.notifier);
    final prev = ref.watch(_lastPerfProvider((we.exercise.id, widget.workout.id)));
    final prevText = prev.maybeWhen(
      data: (sets) => sets.isEmpty
          ? 'No previous data'
          : 'Last: ${sets.take(5).map((s) => '${fmtNum(settings.toDisplay(s.weight ?? 0))}×${s.reps ?? 0}').join(' · ')}${sets.length > 5 ? ' …' : ''}',
      orElse: () => '',
    );
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: AppCard(
        padding: const EdgeInsets.fromLTRB(12, 8, 8, 12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Expanded(
              child: Text(we.exercise.name, style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: context.accent)),
            ),
            PopupMenuButton<String>(
              onSelected: (v) async {
                switch (v) {
                  case 'note':
                    setState(() => _showNotes = true);
                  case 'tempo':
                    final c = TextEditingController(text: we.tempo);
                    final t = await showDialog<String>(
                      context: context,
                      builder: (d) => AlertDialog(
                        title: const Text('Tempo'),
                        content: TextField(controller: c, autofocus: true, decoration: const InputDecoration(hintText: 'e.g. 4-2-0')),
                        actions: [
                          TextButton(onPressed: () => Navigator.pop(d), child: const Text('Cancel')),
                          TextButton(onPressed: () => Navigator.pop(d, c.text.trim()), child: const Text('Save')),
                        ],
                      ),
                    );
                    if (t != null) editor.setTempo(we.id, t);
                  case 'plates':
                    final top = we.sets.map((s) => (s.weight ?? 0).toDouble()).fold<double>(0, (a, b) => a > b ? a : b);
                    if (context.mounted) _plateSheet(context, top, settings);
                  case 'up':
                    editor.moveExercise(we.id, -1);
                  case 'down':
                    editor.moveExercise(we.id, 1);
                  case 'remove':
                    editor.removeExercise(we.id);
                }
              },
              itemBuilder: (c) => const [
                PopupMenuItem(value: 'note', child: Text('Add note')),
                PopupMenuItem(value: 'tempo', child: Text('Set tempo')),
                PopupMenuItem(value: 'plates', child: Text('Plate calculator')),
                PopupMenuItem(value: 'up', child: Text('Move up')),
                PopupMenuItem(value: 'down', child: Text('Move down')),
                PopupMenuItem(value: 'remove', child: Text('Remove exercise')),
              ],
            ),
          ]),
          if (prevText.isNotEmpty) Text(prevText, style: TextStyle(color: context.muted, fontSize: 12)),
          if (we.tempo.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Text('Tempo ${we.tempo}', style: TextStyle(color: context.accent, fontSize: 12, fontWeight: FontWeight.w700)),
            ),
          if (_showNotes || we.notes.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(top: 8, right: 4),
              child: TextFormField(
                initialValue: we.notes,
                minLines: 1,
                maxLines: 3,
                decoration: const InputDecoration(hintText: 'Exercise note', isDense: true),
                onChanged: (v) => editor.setExerciseNotes(we.id, v),
              ),
            ),
          const SizedBox(height: 8),
          Padding(
            padding: const EdgeInsets.only(right: 4),
            child: Row(children: [
              const SizedBox(width: 44),
              _head(context, settings.unitLabel.toUpperCase(), 3),
              _head(context, 'REPS', 2),
              _head(context, settings.rpeScale.toUpperCase(), 2),
              const SizedBox(width: 52),
            ]),
          ),
          for (var i = 0; i < we.sets.length; i++)
            _SetRow(key: ValueKey(we.sets[i].id), workout: widget.workout, we: we, index: i),
          const SizedBox(height: 6),
          Padding(
            padding: const EdgeInsets.only(right: 4),
            child: SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                icon: const Icon(Icons.add, size: 18),
                label: const Text('Add set'),
                onPressed: () => editor.addSet(we.id),
              ),
            ),
          ),
        ]),
      ),
    );
  }

  Widget _head(BuildContext c, String t, int flex) => Expanded(
        flex: flex,
        child: Center(child: Text(t, style: TextStyle(color: c.muted, fontSize: 11, fontWeight: FontWeight.w700))),
      );

  void _plateSheet(BuildContext context, double topKg, AppSettings s) {
    final c = TextEditingController(text: topKg > 0 ? fmtNum(topKg, decimals: 2) : '');
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setS) {
          final kg = parseNum(c.text);
          final plates = kg == null ? null : platesPerSide(target: kg, bar: s.barKg);
          return Padding(
            padding: EdgeInsets.fromLTRB(20, 0, 20, 24 + MediaQuery.of(ctx).viewInsets.bottom),
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Plate calculator', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
              const SizedBox(height: 12),
              TextField(
                controller: c,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: InputDecoration(labelText: 'Total weight (kg)', helperText: 'Bar: ${fmtNum(s.barKg)} kg'),
                onChanged: (_) => setS(() {}),
              ),
              const SizedBox(height: 16),
              if (kg == null)
                const Text('Enter a weight')
              else if (plates == null)
                Text('Not possible with standard plates (1.25 kg smallest).', style: TextStyle(color: context.muted))
              else if (plates.isEmpty)
                const Text('Empty bar')
              else ...[
                Text('Per side', style: TextStyle(color: context.muted)),
                const SizedBox(height: 4),
                Text(plates.map((p) => fmtNum(p, decimals: 2)).join('  +  '),
                    style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
              ],
            ]),
          );
        },
      ),
    );
  }
}

// ─────────────────────────── Set row ───────────────────────────

class _SetRow extends ConsumerWidget {
  final Workout workout;
  final WorkoutExercise we;
  final int index;
  const _SetRow({super.key, required this.workout, required this.we, required this.index});

  InputDecoration _dec(String? hint) => InputDecoration(
        hintText: hint,
        isDense: true,
        contentPadding: const EdgeInsets.symmetric(horizontal: 4, vertical: 14),
      );

  static final _numFormat = [FilteringTextInputFormatter.allow(RegExp(r'[0-9.,]'))];

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = we.sets[index];
    final settings = ref.watch(settingsProvider);
    final editor = ref.read(workoutEditorProvider.notifier);
    final rir = settings.rpeScale == 'rir';

    String wText(double? kg) => kg == null ? '' : fmtNum(settings.toDisplay(kg), decimals: 2);
    String rText(double? rpe) => rpe == null ? '' : fmtNum(rir ? 10 - rpe : rpe);

    final e1 = (s.weight != null && s.reps != null)
        ? estimate1RM(weight: s.weight!, reps: s.reps!, rpe: s.rpe, formula: settings.formula)
        : null;
    final hasTarget = s.prescText.isNotEmpty || s.prescReps != null || s.prescWeight != null;
    final delta = (s.prescWeight != null && s.weight != null) ? s.weight! - s.prescWeight! : null;

    final typeColor = switch (s.type) {
      SetType.warmup => AppColors.warn,
      SetType.backoff => Colors.lightBlueAccent,
      SetType.amrap => AppColors.danger,
      SetType.custom => Colors.purpleAccent,
      _ => context.muted,
    };

    void toggle() {
      if (!s.completed && (s.weight == null || s.reps == null)) {
        snack(context, 'Enter weight and reps first.');
        return;
      }
      final nowDone = !s.completed;
      editor.updateSet(we.id, s.id, (x) => x.completed = nowDone);
      if (nowDone) {
        HapticFeedback.mediumImpact();
        if (settings.autoRest) {
          ref.read(restTimerProvider.notifier).start(s.type == SetType.warmup ? 60 : settings.restSeconds);
        }
      }
    }

    return Dismissible(
      key: ValueKey('dismiss-${s.id}'),
      direction: DismissDirection.endToStart,
      background: Container(
        alignment: Alignment.centerRight,
        padding: const EdgeInsets.only(right: 16),
        margin: const EdgeInsets.only(top: 6),
        decoration: BoxDecoration(color: AppColors.danger, borderRadius: BorderRadius.circular(12)),
        child: const Icon(Icons.delete, color: Colors.white),
      ),
      onDismissed: (_) {
        final removed = s;
        final at = index;
        editor.removeSet(we.id, s.id);
        ScaffoldMessenger.of(context)
          ..hideCurrentSnackBar()
          ..showSnackBar(SnackBar(
            content: const Text('Set removed'),
            action: SnackBarAction(label: 'Undo', onPressed: () => editor.insertSet(we.id, at, removed)),
          ));
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 250),
        margin: const EdgeInsets.only(top: 6),
        padding: const EdgeInsets.fromLTRB(0, 4, 0, 4),
        decoration: BoxDecoration(
          color: s.completed ? context.accent.withValues(alpha: 0.14) : Colors.transparent,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(children: [
          Row(children: [
            InkWell(
              borderRadius: BorderRadius.circular(10),
              onTap: () => editor.cycleSetType(we.id, s.id),
              child: SizedBox(
                width: 44,
                height: 48,
                child: Center(
                  child: Text(
                    SetType.short(s.type).isEmpty ? '${index + 1}' : SetType.short(s.type),
                    style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16, color: typeColor),
                  ),
                ),
              ),
            ),
            Expanded(
              flex: 3,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 3),
                child: TextFormField(
                  key: ValueKey('${s.id}-w'),
                  initialValue: wText(s.weight),
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
                  keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  inputFormatters: _numFormat,
                  decoration: _dec(s.prescWeight == null ? null : wText(s.prescWeight)),
                  onChanged: (v) {
                    final shown = parseNum(v);
                    editor.updateSet(we.id, s.id, (x) => x.weight = shown == null ? null : settings.toKg(shown));
                  },
                ),
              ),
            ),
            Expanded(
              flex: 2,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 3),
                child: TextFormField(
                  key: ValueKey('${s.id}-r'),
                  initialValue: s.reps?.toString() ?? '',
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
                  keyboardType: TextInputType.number,
                  inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                  decoration: _dec(s.prescReps?.toString()),
                  onChanged: (v) => editor.updateSet(we.id, s.id, (x) => x.reps = int.tryParse(v)),
                ),
              ),
            ),
            Expanded(
              flex: 2,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 3),
                child: TextFormField(
                  key: ValueKey('${s.id}-p'),
                  initialValue: rText(s.rpe),
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
                  keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  inputFormatters: _numFormat,
                  decoration: _dec(s.targetRpe == null ? null : rText(s.targetRpe)),
                  onChanged: (v) {
                    final shown = parseNum(v);
                    editor.updateSet(we.id, s.id, (x) => x.rpe = shown == null ? null : (rir ? 10 - shown : shown));
                  },
                ),
              ),
            ),
            SizedBox(
              width: 52,
              height: 52,
              child: IconButton(
                onPressed: toggle,
                icon: AnimatedSwitcher(
                  duration: const Duration(milliseconds: 220),
                  transitionBuilder: (c, a) => ScaleTransition(scale: a, child: c),
                  child: s.completed
                      ? Icon(Icons.check_circle, key: const ValueKey('on'), color: context.accent, size: 34)
                      : Icon(Icons.radio_button_unchecked, key: const ValueKey('off'), color: context.muted, size: 34),
                ),
              ),
            ),
          ]),
          if (hasTarget || e1 != null)
            Padding(
              padding: const EdgeInsets.fromLTRB(48, 0, 8, 2),
              child: Row(children: [
                Expanded(
                  child: Text(
                    [
                      if (hasTarget) 'Target ${s.prescText.isEmpty ? '' : '${s.prescText} '}${s.prescReps != null ? '× ${s.prescReps}' : ''}'.trim(),
                      if (delta != null && delta.abs() > 0.01) 'Δ ${delta > 0 ? '+' : ''}${fmtNum(settings.toDisplay(delta))}',
                    ].join(' · '),
                    style: TextStyle(color: context.muted, fontSize: 11),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                if (e1 != null)
                  Text('e1RM ${fmtNum(settings.toDisplay(e1))}', style: TextStyle(color: context.muted, fontSize: 11)),
              ]),
            ),
        ]),
      ),
    );
  }
}
