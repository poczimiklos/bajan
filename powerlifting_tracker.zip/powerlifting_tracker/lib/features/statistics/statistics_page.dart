import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import '../../core/theme/app_theme.dart';
import '../../core/widgets/common.dart';
import '../../data/models.dart';
import '../../data/settings.dart';
import '../../domain/e1rm.dart';
import '../../domain/stats.dart';
import '../../providers.dart';

const _ranges = <(String, int?)>[
  ('7D', 7),
  ('30D', 30),
  ('90D', 90),
  ('6M', 182),
  ('1Y', 365),
  ('All', null),
];

class StatisticsPage extends ConsumerStatefulWidget {
  const StatisticsPage({super.key});
  @override
  ConsumerState<StatisticsPage> createState() => _StatisticsPageState();
}

class _StatisticsPageState extends ConsumerState<StatisticsPage> {
  int _range = 2; // 90D
  String _lift = 'total'; // squat | bench | deadlift | total

  @override
  Widget build(BuildContext context) {
    final settings = ref.watch(settingsProvider);
    final stats = ref.watch(statsProvider);
    return AsyncView<StatsCalc>(
      value: stats,
      onRetry: () => ref.invalidate(setRecordsProvider),
      data: (calc) {
        final days = _ranges[_range].$2;
        final from = days == null ? null : DateTime.now().subtract(Duration(days: days));
        if (calc.all.isEmpty) {
          return const EmptyState(
            icon: Icons.show_chart,
            title: 'No data yet',
            message: 'Finish a workout with completed sets and your analytics will appear here.',
          );
        }
        final series = _lift == 'total' ? calc.totalSeries(from: from) : calc.e1rmSeries(_lift, from: from);
        final weekly = calc.weeklyVolume(from: from);
        final monthly = calc.monthlyVolume(from: from);
        final liftArg = _lift == 'total' ? null : _lift;
        final bests = calc.bests(from: from, lift: liftArg);
        final avg = calc.avgRpe(from: from);
        final freq = calc.frequencyPerWeek(from: from);

        return ListView(padding: const EdgeInsets.all(16), children: [
          const Text('Statistics', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800)),
          const SizedBox(height: 12),
          SizedBox(
            height: 40,
            child: ListView(scrollDirection: Axis.horizontal, children: [
              for (var i = 0; i < _ranges.length; i++)
                Padding(
                  padding: const EdgeInsets.only(right: 6),
                  child: ChoiceChip(label: Text(_ranges[i].$1), selected: _range == i, onSelected: (_) => setState(() => _range = i)),
                ),
            ]),
          ),
          const SizedBox(height: 8),
          Wrap(spacing: 6, children: [
            for (final l in const ['total', ...Lift.all])
              ChoiceChip(
                label: Text(l == 'total' ? 'SBD total' : Lift.label(l)),
                selected: _lift == l,
                onSelected: (_) => setState(() => _lift = l),
              ),
          ]),
          SectionTitle('Estimated 1RM · ${settings.formula.label}'),
          AppCard(
            padding: const EdgeInsets.fromLTRB(8, 16, 16, 8),
            child: SizedBox(height: 220, child: _LineChart(points: series, settings: settings)),
          ),
          const SectionTitle('Summary'),
          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 10,
            crossAxisSpacing: 10,
            childAspectRatio: 1.9,
            children: [
              StatTile(label: 'Total reps', value: '${calc.totalReps(from: from)}'),
              StatTile(label: 'Average RPE', value: avg == null ? '–' : fmtNum(avg)),
              StatTile(label: 'Workouts / week', value: freq == null ? '–' : fmtNum(freq)),
              StatTile(
                label: 'Volume',
                value: fmtNum(settings.toDisplay(calc.since(from).fold(0.0, (a, s) => a + s.weight * s.reps)), decimals: 0),
                unit: settings.unitLabel,
              ),
            ],
          ),
          const SectionTitle('Weekly volume'),
          AppCard(
            padding: const EdgeInsets.fromLTRB(8, 16, 16, 8),
            child: SizedBox(height: 180, child: _BarChart(points: weekly, settings: settings, labelFmt: DateFormat('d MMM'))),
          ),
          const SectionTitle('Monthly volume'),
          for (final m in monthly.reversed.take(12))
            Padding(
              padding: const EdgeInsets.only(bottom: 6),
              child: AppCard(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                child: Row(children: [
                  Expanded(child: Text(DateFormat('MMMM yyyy').format(m.date))),
                  Text('${fmtNum(settings.toDisplay(m.value), decimals: 0)} ${settings.unitLabel}', style: const TextStyle(fontWeight: FontWeight.w700)),
                ]),
              ),
            ),
          SectionTitle('Records in range', trailing: TextButton(onPressed: () => context.push('/records'), child: const Text('All records'))),
          _BestTile('Heaviest weight', bests.heaviest, settings, (s) => fmtNum(settings.toDisplay(s.weight))),
          _BestTile('Best e1RM', bests.bestE1rm, settings, (s) => fmtNum(settings.toDisplay(calc.e1rm(s) ?? 0))),
          _BestTile('Best rep set', bests.mostReps, settings, (s) => '${s.reps} reps'),
          if (calc.bestActualTotal() != null)
            Padding(
              padding: const EdgeInsets.only(bottom: 6),
              child: AppCard(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                child: Row(children: [
                  const Expanded(child: Text('Highest SBD total (actual)', style: TextStyle(fontWeight: FontWeight.w700))),
                  Text('${fmtNum(settings.toDisplay(calc.bestActualTotal()!))} ${settings.unitLabel}',
                      style: TextStyle(color: context.accent, fontWeight: FontWeight.w800)),
                ]),
              ),
            ),
          const SizedBox(height: 24),
        ]);
      },
    );
  }
}

class _BestTile extends StatelessWidget {
  final String title;
  final SetRecord? rec;
  final AppSettings settings;
  final String Function(SetRecord) value;
  const _BestTile(this.title, this.rec, this.settings, this.value);

  @override
  Widget build(BuildContext context) {
    final r = rec;
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: AppCard(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        child: Row(children: [
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
              if (r != null)
                Text(
                  '${r.exerciseName} · ${fmtNum(settings.toDisplay(r.weight))}${settings.unitLabel} × ${r.reps} · ${DateFormat('d MMM yyyy').format(r.date)}',
                  style: TextStyle(color: context.muted, fontSize: 12),
                ),
            ]),
          ),
          Text(r == null ? '–' : value(r), style: TextStyle(color: context.accent, fontWeight: FontWeight.w800)),
        ]),
      ),
    );
  }
}

class _LineChart extends StatelessWidget {
  final List<DatedValue> points;
  final AppSettings settings;
  const _LineChart({required this.points, required this.settings});

  @override
  Widget build(BuildContext context) {
    if (points.length < 2) {
      return Center(
        child: Text(points.isEmpty ? 'No data in this range' : 'Need at least two sessions to draw a trend',
            style: TextStyle(color: context.muted)),
      );
    }
    final t0 = points.first.date.millisecondsSinceEpoch.toDouble();
    const day = 86400000.0;
    final spots = [
      for (final p in points) FlSpot((p.date.millisecondsSinceEpoch - t0) / day, settings.toDisplay(p.value)),
    ];
    final ys = spots.map((s) => s.y);
    final minY = ys.reduce((a, b) => a < b ? a : b);
    final maxY = ys.reduce((a, b) => a > b ? a : b);
    final pad = ((maxY - minY) * 0.15).clamp(2, 1000).toDouble();
    final spanDays = spots.last.x.clamp(1, 100000).toDouble();
    return LineChart(LineChartData(
      minY: (minY - pad).floorToDouble(),
      maxY: (maxY + pad).ceilToDouble(),
      gridData: FlGridData(
        drawVerticalLine: false,
        getDrawingHorizontalLine: (v) => FlLine(color: context.muted.withValues(alpha: 0.15), strokeWidth: 1),
      ),
      borderData: FlBorderData(show: false),
      titlesData: FlTitlesData(
        topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
        rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
        leftTitles: AxisTitles(
          sideTitles: SideTitles(
            showTitles: true,
            reservedSize: 42,
            getTitlesWidget: (v, m) => Text(fmtNum(v, decimals: 0), style: TextStyle(color: context.muted, fontSize: 10)),
          ),
        ),
        bottomTitles: AxisTitles(
          sideTitles: SideTitles(
            showTitles: true,
            reservedSize: 26,
            interval: (spanDays / 4).clamp(1, 100000).toDouble(),
            getTitlesWidget: (v, m) => Padding(
              padding: const EdgeInsets.only(top: 6),
              child: Text(
                DateFormat('d MMM').format(DateTime.fromMillisecondsSinceEpoch((t0 + v * day).round())),
                style: TextStyle(color: context.muted, fontSize: 10),
              ),
            ),
          ),
        ),
      ),
      lineTouchData: LineTouchData(
        touchTooltipData: LineTouchTooltipData(
          getTooltipItems: (touched) => [
            for (final t in touched)
              LineTooltipItem(
                '${fmtNum(t.y)} ${settings.unitLabel}\n${DateFormat('d MMM yyyy').format(DateTime.fromMillisecondsSinceEpoch((t0 + t.x * day).round()))}',
                const TextStyle(fontWeight: FontWeight.w700, fontSize: 12),
              ),
          ],
        ),
      ),
      lineBarsData: [
        LineChartBarData(
          spots: spots,
          isCurved: true,
          preventCurveOverShooting: true,
          color: context.accent,
          barWidth: 3,
          dotData: FlDotData(show: spots.length <= 40),
          belowBarData: BarAreaData(show: true, color: context.accent.withValues(alpha: 0.12)),
        ),
      ],
    ));
  }
}

class _BarChart extends StatelessWidget {
  final List<DatedValue> points;
  final AppSettings settings;
  final DateFormat labelFmt;
  const _BarChart({required this.points, required this.settings, required this.labelFmt});

  @override
  Widget build(BuildContext context) {
    if (points.isEmpty) return Center(child: Text('No data in this range', style: TextStyle(color: context.muted)));
    final shown = points.length > 26 ? points.sublist(points.length - 26) : points;
    final every = (shown.length / 5).ceil().clamp(1, 100);
    return BarChart(BarChartData(
      gridData: FlGridData(
        drawVerticalLine: false,
        getDrawingHorizontalLine: (v) => FlLine(color: context.muted.withValues(alpha: 0.15), strokeWidth: 1),
      ),
      borderData: FlBorderData(show: false),
      titlesData: FlTitlesData(
        topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
        rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
        leftTitles: AxisTitles(
          sideTitles: SideTitles(
            showTitles: true,
            reservedSize: 46,
            getTitlesWidget: (v, m) => Text(
              v >= 1000 ? '${fmtNum(v / 1000)}k' : fmtNum(v, decimals: 0),
              style: TextStyle(color: context.muted, fontSize: 10),
            ),
          ),
        ),
        bottomTitles: AxisTitles(
          sideTitles: SideTitles(
            showTitles: true,
            reservedSize: 24,
            getTitlesWidget: (v, m) {
              final i = v.toInt();
              if (i < 0 || i >= shown.length || i % every != 0) return const SizedBox.shrink();
              return Padding(
                padding: const EdgeInsets.only(top: 6),
                child: Text(labelFmt.format(shown[i].date), style: TextStyle(color: context.muted, fontSize: 10)),
              );
            },
          ),
        ),
      ),
      barGroups: [
        for (var i = 0; i < shown.length; i++)
          BarChartGroupData(x: i, barRods: [
            BarChartRodData(
              toY: settings.toDisplay(shown[i].value),
              color: context.accent,
              width: shown.length > 14 ? 7 : 14,
              borderRadius: BorderRadius.circular(3),
            ),
          ]),
      ],
    ));
  }
}
