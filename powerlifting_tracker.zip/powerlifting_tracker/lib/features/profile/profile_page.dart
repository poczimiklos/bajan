import 'dart:convert';
import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:share_plus/share_plus.dart';
import '../../core/theme/app_theme.dart';
import '../../core/widgets/common.dart';
import '../../data/models.dart';
import '../../domain/e1rm.dart';
import '../../providers.dart';
import '../training/workout_editor.dart';

class ProfilePage extends ConsumerWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = ref.watch(settingsProvider);
    final notifier = ref.read(settingsProvider.notifier);
    final bw = ref.watch(bodyweightProvider).valueOrNull ?? const <BodyweightEntry>[];
    final sync = ref.watch(syncStatusProvider).valueOrNull;

    Widget choice<T>(String title, T value, Map<T, String> options, void Function(T) onChanged) => Padding(
          padding: const EdgeInsets.symmetric(vertical: 6),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: TextStyle(color: context.muted, fontSize: 12)),
            const SizedBox(height: 6),
            Wrap(spacing: 6, runSpacing: 4, children: [
              for (final e in options.entries)
                ChoiceChip(label: Text(e.value), selected: value == e.key, onSelected: (_) => onChanged(e.key)),
            ]),
          ]),
        );

    return ListView(padding: const EdgeInsets.all(16), children: [
      const Text('Profile', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800)),
      const SizedBox(height: 16),
      AppCard(
        child: Row(children: [
          CircleAvatar(
            radius: 30,
            backgroundColor: context.accent.withValues(alpha: 0.25),
            child: Text(s.username.isEmpty ? '?' : s.username[0].toUpperCase(),
                style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800, color: context.accent)),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(s.username, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
              Text(
                bw.isEmpty ? 'No bodyweight logged' : '${fmtNum(s.toDisplay(bw.first.kg))} ${s.unitLabel} · ${DateFormat('d MMM').format(bw.first.date)}',
                style: TextStyle(color: context.muted),
              ),
            ]),
          ),
          IconButton(
            icon: const Icon(Icons.edit_outlined),
            onPressed: () => _editProfile(context, ref),
          ),
        ]),
      ),
      if (s.experience.isNotEmpty || s.goals.isNotEmpty)
        Padding(
          padding: const EdgeInsets.only(top: 10),
          child: AppCard(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              if (s.experience.isNotEmpty) Text('Experience: ${s.experience}'),
              if (s.goals.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 4), child: Text('Goals: ${s.goals}')),
            ]),
          ),
        ),
      // ── bodyweight ──
      SectionTitle('Bodyweight', trailing: TextButton.icon(
        icon: const Icon(Icons.add, size: 18),
        label: const Text('Log'),
        onPressed: () => _addBodyweight(context, ref),
      )),
      if (bw.isEmpty)
        AppCard(child: Text('Log your bodyweight to get relative strength scores (DOTS).', style: TextStyle(color: context.muted)))
      else
        for (final e in bw.take(5))
          Padding(
            padding: const EdgeInsets.only(bottom: 6),
            child: AppCard(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
              child: Row(children: [
                Expanded(child: Text(DateFormat('EEE d MMM yyyy').format(e.date))),
                Text('${fmtNum(s.toDisplay(e.kg))} ${s.unitLabel}', style: const TextStyle(fontWeight: FontWeight.w700)),
                IconButton(
                  icon: const Icon(Icons.close, size: 18),
                  onPressed: () async {
                    await ref.read(bodyweightRepoProvider).delete(e.id);
                    refreshAll(ref);
                  },
                ),
              ]),
            ),
          ),
      // ── preferences ──
      const SectionTitle('Preferences'),
      AppCard(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          choice<String>('Weight unit', s.unit, const {'kg': 'kg', 'lb': 'lb'}, (v) => notifier.update((x) => x.copyWith(unit: v))),
          choice<E1rmFormula>(
            'Estimated 1RM formula',
            s.formula,
            {for (final f in E1rmFormula.values) f: f.label},
            (v) => notifier.update((x) => x.copyWith(formula: v)),
          ),
          choice<String>('Intensity scale', s.rpeScale, const {'rpe': 'RPE', 'rir': 'RIR'}, (v) => notifier.update((x) => x.copyWith(rpeScale: v))),
          choice<String>('Theme', s.theme, const {'dark': 'Dark', 'light': 'Light', 'system': 'System'}, (v) => notifier.update((x) => x.copyWith(theme: v))),
          choice<String>('Sex (for DOTS)', s.sex, const {'m': 'Male', 'f': 'Female'}, (v) => notifier.update((x) => x.copyWith(sex: v))),
        ]),
      ),
      const SectionTitle('Rest timer & bar'),
      AppCard(
        child: Column(children: [
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Start automatically when a set is completed'),
            value: s.autoRest,
            onChanged: (v) => notifier.update((x) => x.copyWith(autoRest: v)),
          ),
          Row(children: [
            const Expanded(child: Text('Default rest')),
            IconButton(
              onPressed: () => notifier.update((x) => x.copyWith(restSeconds: (x.restSeconds - 15).clamp(15, 900))),
              icon: const Icon(Icons.remove_circle_outline),
            ),
            Text('${s.restSeconds ~/ 60}:${(s.restSeconds % 60).toString().padLeft(2, '0')}', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 18)),
            IconButton(
              onPressed: () => notifier.update((x) => x.copyWith(restSeconds: (x.restSeconds + 15).clamp(15, 900))),
              icon: const Icon(Icons.add_circle_outline),
            ),
          ]),
          choice<double>('Barbell weight', s.barKg, const {20: '20 kg', 15: '15 kg'}, (v) => notifier.update((x) => x.copyWith(barKg: v))),
        ]),
      ),
      const SectionTitle('Training max (for % programs)'),
      AppCard(
        child: Column(children: [
          Text('Used by 5/3/1, Texas Method and other %-based prescriptions. 0 = automatic (90% of your current e1RM).',
              style: TextStyle(color: context.muted, fontSize: 12)),
          const SizedBox(height: 8),
          for (final l in Lift.all)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 4),
              child: Row(children: [
                SizedBox(width: 90, child: Text(Lift.label(l))),
                Expanded(
                  child: TextFormField(
                    key: ValueKey('tm-$l-${s.unit}'),
                    initialValue: (s.trainingMax[l] ?? 0) > 0 ? fmtNum(s.toDisplay(s.trainingMax[l]!), decimals: 2) : '',
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    decoration: InputDecoration(hintText: 'auto', suffixText: s.unitLabel),
                    onChanged: (v) {
                      final shown = parseNum(v);
                      notifier.update((x) => x.copyWith(trainingMax: {...x.trainingMax, l: shown == null ? 0 : x.toKg(shown)}));
                    },
                  ),
                ),
              ]),
            ),
        ]),
      ),
      // ── data ──
      const SectionTitle('Data'),
      AppCard(
        padding: EdgeInsets.zero,
        child: Column(children: [
          ListTile(
            leading: const Icon(Icons.upload_file),
            title: const Text('Export / back up data'),
            subtitle: const Text('JSON file with all workouts, programs and records'),
            onTap: () => _export(context, ref),
          ),
          const Divider(height: 1),
          ListTile(
            leading: const Icon(Icons.restore),
            title: const Text('Restore from backup'),
            subtitle: const Text('Replaces all data on this device'),
            onTap: () => _restore(context, ref),
          ),
          const Divider(height: 1),
          ListTile(
            leading: const Icon(Icons.cloud_sync_outlined),
            title: Text(sync == null
                ? 'Cloud sync'
                : sync.configured
                    ? 'Cloud sync · ${sync.pending} change${sync.pending == 1 ? '' : 's'} pending'
                    : 'Cloud sync not configured (${sync.pending} change${sync.pending == 1 ? '' : 's'} queued locally)'),
            subtitle: const Text('Local data is always saved first; sync runs in the background layer'),
            onTap: () async {
              final n = await ref.read(syncServiceProvider).syncNow();
              ref.invalidate(syncStatusProvider);
              if (context.mounted) {
                snack(context, ref.read(syncServiceProvider).remote.isConfigured ? 'Synced $n changes' : 'No backend configured – see README.');
              }
            },
          ),
        ]),
      ),
      const SizedBox(height: 32),
    ]);
  }

  Future<void> _editProfile(BuildContext context, WidgetRef ref) async {
    final s = ref.read(settingsProvider);
    final name = TextEditingController(text: s.username);
    final exp = TextEditingController(text: s.experience);
    final goals = TextEditingController(text: s.goals);
    final ok = await showDialog<bool>(
      context: context,
      builder: (d) => AlertDialog(
        title: const Text('Edit profile'),
        content: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(controller: name, decoration: const InputDecoration(labelText: 'Username')),
            const SizedBox(height: 12),
            TextField(controller: exp, decoration: const InputDecoration(labelText: 'Training experience', hintText: 'e.g. 3 years')),
            const SizedBox(height: 12),
            TextField(controller: goals, minLines: 1, maxLines: 3, decoration: const InputDecoration(labelText: 'Current goals')),
          ]),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Cancel')),
          TextButton(onPressed: () => Navigator.pop(d, true), child: const Text('Save')),
        ],
      ),
    );
    if (ok != true) return;
    await ref.read(settingsProvider.notifier).update(
          (x) => x.copyWith(username: name.text.trim().isEmpty ? 'Lifter' : name.text.trim(), experience: exp.text.trim(), goals: goals.text.trim()),
        );
  }

  Future<void> _addBodyweight(BuildContext context, WidgetRef ref) async {
    final s = ref.read(settingsProvider);
    final c = TextEditingController();
    final v = await showDialog<double>(
      context: context,
      builder: (d) => AlertDialog(
        title: const Text('Log bodyweight'),
        content: TextField(
          controller: c,
          autofocus: true,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: InputDecoration(suffixText: s.unitLabel),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(d), child: const Text('Cancel')),
          TextButton(onPressed: () => Navigator.pop(d, parseNum(c.text)), child: const Text('Save')),
        ],
      ),
    );
    if (v == null || v <= 0) return;
    await ref.read(bodyweightRepoProvider).add(BodyweightEntry(date: DateTime.now(), kg: s.toKg(v)));
    refreshAll(ref);
  }

  Future<void> _export(BuildContext context, WidgetRef ref) async {
    try {
      final f = await ref.read(backupServiceProvider).exportToFile();
      await Share.shareXFiles([XFile(f.path)], text: 'Powerlifting Tracker backup');
    } catch (e) {
      if (context.mounted) snack(context, 'Export failed: $e');
    }
  }

  Future<void> _restore(BuildContext context, WidgetRef ref) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (d) => AlertDialog(
        title: const Text('Restore backup?'),
        content: const Text('All current workouts, programs and records on this device will be replaced.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Cancel')),
          TextButton(onPressed: () => Navigator.pop(d, true), child: const Text('Restore')),
        ],
      ),
    );
    if (ok != true) return;
    try {
      final res = await FilePicker.platform.pickFiles(type: FileType.any);
      final path = res?.files.single.path;
      if (path == null) return;
      final json = utf8.decode(await File(path).readAsBytes());
      await ref.read(backupServiceProvider).restoreFromJson(json);
      await ref.read(exerciseRepoProvider).seedIfNeeded();
      ref.read(workoutEditorProvider.notifier).closeEditor();
      await ref.read(workoutEditorProvider.notifier).restoreActive();
      refreshAll(ref);
      if (context.mounted) snack(context, 'Backup restored.');
    } catch (e) {
      if (context.mounted) snack(context, 'Restore failed: $e');
    }
  }
}
