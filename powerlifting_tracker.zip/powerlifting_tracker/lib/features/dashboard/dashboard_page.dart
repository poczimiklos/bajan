import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import '../../core/theme/app_theme.dart';
import '../../core/widgets/common.dart';
import '../../data/models.dart';
import '../../domain/scores.dart';
import '../../domain/stats.dart';
import '../../providers.dart';
import '../training/plan.dart';
import '../training/pr_dialog.dart';
import '../training/start_workout.dart';
import '../training/workout_editor.dart';

class DashboardPage extends ConsumerWidget {
  const DashboardPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final settings = ref.watch(settingsProvider);
    final stats = ref.watch(statsProvider);
    final plan = ref.watch(activePlanProvider);
    final records = ref.watch(recordsProvider).valueOrNull ?? const <PersonalRecord>[];
    final bw = ref.watch(bodyweightProvider).valueOrNull ?? const <BodyweightEntry>[];
    final active = ref.watch(workoutEditorProvider);

    return AsyncView<StatsCalc>(
      value: stats,
      onRetry: () => ref.invalidate(setRecordsProvider),
      data: (calc) {
        final now = DateTime.now();
        final ws = weekStart(now);
        final weekVol = calc.volumeBetween(ws, ws.add(const Duration(days: 7)));
        final weekWorkouts = calc.workoutCount(from: ws);
        final total = calc.currentTotal();
        final dots = (total != null && bw.isNotEmpty)
            ? dotsScore(totalKg: total, bodyweightKg: bw.first.kg, male: settings.sex == 'm')
            : null;
        final recent = records.where((r) => r.previous != null && r.kind != 'reps').take(4).toList();

        return ListView(padding: const EdgeInsets.all(16), children: [
          Text(DateFormat('EEEE, d MMMM').format(now), style: TextStyle(color: context.muted)),
          const SizedBox(height: 2),
          Text('Welcome back, ${settings.username}', style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
          const SizedBox(height: 16),
          _PlanCard(plan: plan.valueOrNull, loading: plan.isLoading),
          const SizedBox(height: 12),
          if (active != null && active.status == 'active')
            FilledButton.icon(
              icon: const Icon(Icons.play_arrow_rounded),
              onPressed: () => context.push('/workout'),
              label: const Text('Resume workout'),
            )
          else
            FilledButton.icon(
              icon: const Icon(Icons.bolt),
              onPressed: () => StartWorkout.empty(context, ref),
              label: const Text('Quick start workout'),
            ),
          const SectionTitle('This week'),
          GridView.count(
            crossAxisCount: 3,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 10,
            crossAxisSpacing: 10,
            childAspectRatio: 1.15,
            children: [
              StatTile(label: 'Volume', value: fmtNum(settings.toDisplay(weekVol), decimals: 0), unit: settings.unitLabel, icon: Icons.scale),
              StatTile(label: 'Workouts', value: '$weekWorkouts', icon: Icons.fitness_center),
              StatTile(label: 'Streak', value: '${calc.weekStreak()}', unit: 'wk', icon: Icons.local_fire_department),
            ],
          ),
          const SectionTitle('Estimated 1RM'),
          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 10,
            crossAxisSpacing: 10,
            childAspectRatio: 1.9,
            children: [
              for (final l in Lift.all)
                StatTile(
                  label: Lift.label(l),
                  value: calc.currentE1rm(l) == null ? '–' : fmtNum(settings.toDisplay(calc.currentE1rm(l)!)),
                  unit: settings.unitLabel,
                ),
              StatTile(
                label: 'SBD total${dots != null ? ' · DOTS ${fmtNum(dots)}' : ''}',
                value: total == null ? '–' : fmtNum(settings.toDisplay(total)),
                unit: settings.unitLabel,
                valueColor: context.accent,
              ),
            ],
          ),
          SectionTitle('Recent records', trailing: TextButton(onPressed: () => context.push('/records'), child: const Text('All'))),
          if (recent.isEmpty)
            AppCard(child: Text('No new records yet. They appear automatically when you beat a previous best.', style: TextStyle(color: context.muted)))
          else
            for (final r in recent)
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: AppCard(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  child: Row(children: [
                    Icon(Icons.emoji_events, color: context.accent),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(r.exerciseName, style: const TextStyle(fontWeight: FontWeight.w700)),
                        Text('${r.kindLabel} · ${DateFormat('d MMM').format(r.date)}', style: TextStyle(color: context.muted, fontSize: 12)),
                      ]),
                    ),
                    Text(prValueText(r, settings), style: TextStyle(color: context.accent, fontWeight: FontWeight.w800)),
                  ]),
                ),
              ),
          const SizedBox(height: 24),
        ]);
      },
    );
  }
}

class _PlanCard extends ConsumerWidget {
  final ActivePlan? plan;
  final bool loading;
  const _PlanCard({required this.plan, required this.loading});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final p = plan;
    if (p == null) {
      return AppCard(
        onTap: loading ? null : () => context.go('/programs'),
        child: Row(children: [
          Icon(Icons.event_note, color: context.accent),
          const SizedBox(width: 12),
          const Expanded(
            child: Text('No active program. Pick or build one in Programs.', style: TextStyle(fontWeight: FontWeight.w600)),
          ),
          const Icon(Icons.chevron_right),
        ]),
      );
    }
    final day = p.today;
    final df = DateFormat('EEE d MMM');
    String sub;
    if (p.notStarted) {
      sub = 'Starts ${df.format(p.block.startDate!)}';
    } else if (p.finished) {
      sub = 'Block finished';
    } else if (day != null) {
      sub = 'Today: ${day.name}';
    } else if (p.next != null) {
      sub = 'Rest day · next: ${p.next!.name} on ${df.format(p.nextDate!)}';
    } else {
      sub = 'Nothing scheduled';
    }
    return AppCard(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(p.program.name, style: TextStyle(color: context.muted, fontSize: 12)),
        const SizedBox(height: 2),
        Row(children: [
          Expanded(child: Text('${p.block.name} · ${p.finished ? 'done' : p.weekLabel}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800))),
          if (day != null && day.tag.isNotEmpty) Chip(label: Text(day.tag), visualDensity: VisualDensity.compact),
        ]),
        const SizedBox(height: 6),
        Text(sub, style: TextStyle(color: context.muted)),
        if (!p.finished && !p.notStarted)
          Padding(
            padding: const EdgeInsets.only(top: 10),
            child: LinearProgressIndicator(
              value: (p.week + 1) / p.block.weekCount,
              minHeight: 6,
              borderRadius: BorderRadius.circular(3),
              color: context.accent,
              backgroundColor: context.fieldBg,
            ),
          ),
        if (day != null) ...[
          const SizedBox(height: 14),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              icon: const Icon(Icons.play_arrow),
              label: Text('Start ${day.name}'),
              onPressed: () => StartWorkout.fromPlan(context, ref, p),
            ),
          ),
        ] else if (p.next != null) ...[
          const SizedBox(height: 14),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              icon: const Icon(Icons.fast_forward),
              label: Text('Do ${p.next!.name} now'),
              onPressed: () => StartWorkout.fromPlan(context, ref, p, useNext: true),
            ),
          ),
        ],
      ]),
    );
  }
}
