# Powerlifting Tracker (Flutter)

Offline-first powerlifting tracker: workout logging with prescribed-vs-actual sets, RPE/RIR, rest timer,
block/week based programs (incl. your coach's e2.0 block), PR detection, analytics, backup/restore and a
separate cloud-sync layer.

## Run it

Requires Flutter >= 3.27 (uses `Color.withValues`).

```bash
cd powerlifting_tracker
flutter create . --platforms=android,ios   # generates android/ and ios/ (keeps lib/ and pubspec.yaml)
flutter pub get
flutter analyze
flutter test
flutter run
```

> This code was written without access to a Flutter SDK, so it has **not been compiled yet**. Run
> `flutter analyze` first and fix any small API drift; the logic is covered by unit tests in `test/`.

## Architecture (feature-first, clean layers)

```
lib/
  main.dart, app.dart            bootstrap (seed library, restore unfinished workout), theme, router
  providers.dart                 Riverpod wiring
  core/                          theme (dark #0D0F12 / #181B20 / lime accent), router, shared widgets
  domain/                        PURE Dart: e1RM formulas (+RPE chart), DOTS, plate calculator,
                                 coach load-notation parser, statistics calculator
  data/                          models, sqflite schema + migrations hook, repositories,
                                 sample programs, settings (SharedPreferences), backup, sync outbox
  features/
    dashboard/ training/ programs/ statistics/ profile/ shell/
```

* **Offline first:** every change is written to SQLite immediately (workout edits are debounced 400 ms). An
  unfinished workout is restored on next launch.
* **Sync layer:** every write also queues a row in `sync_outbox`. `SyncService` drains it through a
  `RemoteGateway`. The default is `NoRemote`, so the app never depends on connectivity. To enable a cloud:

```dart
class SupabaseGateway implements RemoteGateway {
  final SupabaseClient c;
  SupabaseGateway(this.c);
  @override bool get isConfigured => true;
  @override Future<void> upsert(String table, List<Map<String, Object?>> rows) async {
    if (rows.isNotEmpty) await c.from(table).upsert(rows);
  }
  @override Future<void> remove(String table, List<String> ids) async {
    await c.from(table).delete().inFilter('id', ids);
  }
}
// override remoteGatewayProvider in main(); create matching tables with a user_id column and RLS.
```

## Your data

* Programs -> **Sample programs -> "e2.0 · Coach program"** imports Block 1 (Tue/Thu/Sat, 5 weeks) with all
  weights from the sheet. Tap **Activate block**; the start date is 2026-10-20 (week 4 = 10 Nov).
* Day tags such as `SQ1 BP2` are shown as chips: 1 = primary, 2 = secondary lift of that day.
* Import mapping assumptions (edit freely): the two "Tempo 4-2-0" rows = tempo low bar squat,
  "squat" = low bar squat, "deadlift" = sumo deadlift. `cmbf` / `combh` are kept as custom exercises.
* Estimated 1RM defaults to the **RPE-chart method**, which reproduces your sheet's E1RM column
  (e.g. 207.5 x3 @6 = 255.9).

## Not done yet

* Historical blocks of workbook "E" (needs the spreadsheet importer; only the structure was captured).
* Candito 6-week program, competition attempt planner, Wilks/IPF GL (DOTS is included).
* ARB localisation (UI strings are English), profile picture, local notification for the rest timer.
* Cloud backend adapter (interface + queue are ready, see above).
