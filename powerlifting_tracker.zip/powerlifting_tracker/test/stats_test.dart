import 'package:flutter_test/flutter_test.dart';
import 'package:powerlifting_tracker/data/models.dart';
import 'package:powerlifting_tracker/domain/e1rm.dart';
import 'package:powerlifting_tracker/domain/stats.dart';

SetRecord _s(DateTime d, double w, int r, {String lift = 'squat', bool variation = false, String type = 'working', double? rpe}) =>
    SetRecord(
      date: d,
      workoutId: d.toIso8601String(),
      exerciseId: 'x',
      exerciseName: 'x',
      lift: lift,
      variation: variation,
      setType: type,
      weight: w,
      reps: r,
      rpe: rpe,
    );

void main() {
  test('series ignores warm-ups and variations', () {
    final calc = StatsCalc([
      _s(DateTime(2026, 1, 1), 100, 5),
      _s(DateTime(2026, 1, 1), 60, 5, type: 'warmup'),
      _s(DateTime(2026, 1, 1), 200, 5, variation: true),
      _s(DateTime(2026, 1, 8), 110, 5),
    ], E1rmFormula.epley);
    final series = calc.e1rmSeries('squat');
    expect(series.length, 2);
    expect(series.first.value, closeTo(116.67, 0.01));
    expect(series.last.value, closeTo(128.33, 0.01));
  });

  test('total needs all three lifts and carries forward', () {
    final calc = StatsCalc([
      _s(DateTime(2026, 1, 1), 100, 1, lift: 'squat'),
      _s(DateTime(2026, 1, 2), 80, 1, lift: 'bench'),
      _s(DateTime(2026, 1, 3), 120, 1, lift: 'deadlift'),
      _s(DateTime(2026, 1, 10), 105, 1, lift: 'squat'),
    ], E1rmFormula.epley);
    final t = calc.totalSeries();
    expect(t.length, 2);
    expect(t.first.value, 300);
    expect(t.last.value, 305);
  });

  test('week start is Monday', () {
    expect(weekStart(DateTime(2026, 11, 11)), DateTime(2026, 11, 9));
  });

  test('tag description', () {
    expect(describeTag('SQ1 BP2'), 'SQ1 = primary squat · BP2 = secondary bench');
  });
}
