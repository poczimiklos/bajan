import 'package:flutter_test/flutter_test.dart';
import 'package:powerlifting_tracker/domain/e1rm.dart';
import 'package:powerlifting_tracker/domain/load_parser.dart';
import 'package:powerlifting_tracker/domain/plates.dart';

void main() {
  test('Epley', () {
    expect(estimate1RM(weight: 100, reps: 5), closeTo(116.67, 0.01));
    expect(estimate1RM(weight: 100, reps: 1), 100);
    expect(estimate1RM(weight: 0, reps: 5), isNull);
  });

  test('RPE chart matches coach sheet (207.5 x3 @6 ~ 255.9)', () {
    final v = estimate1RM(weight: 207.5, reps: 3, rpe: 6, formula: E1rmFormula.rpeChart)!;
    expect(v, closeTo(255.9, 0.2));
    // 230 x3 @6 -> ~283.6
    final d = estimate1RM(weight: 230, reps: 3, rpe: 6, formula: E1rmFormula.rpeChart)!;
    expect(d, closeTo(283.6, 0.3));
  });

  test('load notation', () {
    final a = parsePrescription('[145-155] R5-6');
    expect(a.weight, 145);
    expect(a.weightMax, 155);
    expect(a.rpeMin, 5);
    expect(a.rpeMax, 6);
    final b = parsePrescription('[140-152,5]cR6');
    expect(b.weightMax, 152.5);
    expect(b.isConstant, isTrue);
    expect(b.rpeMin, 6);
    expect(parsePrescription('R8-9').weight, isNull);
    expect(parsePrescription('Repeat R8-9').isRepeat, isTrue);
    expect(parsePrescription('max').isMax, isTrue);
    expect(parsePrescription('192,5').weight, 192.5);
    expect(parsePrescription('75%').isPercent, isTrue);
  });

  test('reps ranges', () {
    expect(parseReps('8-10'), (8, 10));
    expect(parseReps('8-7'), (7, 8));
    expect(parseReps('5'), (5, 5));
  });

  test('plates', () {
    expect(platesPerSide(target: 100), [25, 15]);
    expect(platesPerSide(target: 20), isEmpty);
    expect(platesPerSide(target: 21), isNull);
  });
}
